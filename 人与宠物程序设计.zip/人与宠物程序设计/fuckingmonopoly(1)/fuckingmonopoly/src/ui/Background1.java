package ui;

import java.awt.Graphics;
import java.awt.Image;

import util.FileUtil1;

import model.BackgroundModel1;


/**
 * 
 * �������²�
 * 
 * @author MOVELIGHTS
 * 
 */
public class Background1 extends Layer1 {

	/**
	 * ����ͼƬ
	 */
	private Image bg = null;
	/**
	 * 
	 * ����ģ��
	 * 
	 */
	private BackgroundModel1 background = null;
	private JPanelGame1 panel;

	protected Background1(int x, int y, int w, int h,
			BackgroundModel1 background,JPanelGame1 panel) {
		super(x, y, w, h);
		this.background = background;
		this.panel = panel;
	}

	public void paint(Graphics g) {
		// ���Ʊ���
		this.paintBg(g);
	}
	/**
	 * 
	 * ����������
	 * 
	 */
	public void moveToBack() {
		this.panel.getLayeredPane().moveToBack(this);
	}

	/**
	 * 
	 * ����������
	 * 
	 */
	public void moveToFront() {
		this.panel.getLayeredPane().moveToFront(this);
	}
	
	/**
	 * 
	 * �������Ʒ���
	 * 
	 */
	public void paintBg(Graphics g){
		g.drawImage(this.bg, 0, 0, this.bg.getWidth(null),
				this.bg.getHeight(null), 0, 0, this.bg.getWidth(null),
				this.bg.getHeight(null), null);
	}
	

	@Override
	public void startPanel() {
		this.bg = background.getBg();
	}

}
