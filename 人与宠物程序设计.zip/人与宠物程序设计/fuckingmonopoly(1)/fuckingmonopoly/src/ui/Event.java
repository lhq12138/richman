package ui;

import java.awt.Graphics;
import model.AutoplayerModel;

import model.EventsModel;


/**
 * �¼���ʾUI
 * 
 * @author MOVELIGHTS
 * 
 */
public class Event extends Layer {

	private EventsModel events = null;
	
	protected Event(int x, int y, int w, int h,EventsModel events) {
		super(x, y, w, h);
		this.events = events;
	}

	public void paint(Graphics g) {
		this.paintEvent(g);
	}
	
	private void paintEvent(Graphics g) {
		if (events.getStartTick() < events.getNowTick() && events.getNextTick() >= events.getNowTick()){
			//����ͼ����
			g.drawImage(events.getBG_BRACK(), 0, 0, 2000, 2000, 0, 0, 1, 1, null);
			
			

		}
	}
	
	@Override
	public void startPanel() {	
	}

}
