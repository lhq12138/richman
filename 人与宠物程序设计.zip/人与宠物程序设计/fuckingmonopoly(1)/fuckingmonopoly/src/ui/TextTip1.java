package ui;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseMotionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import control.GameRunning1;

import model.TextTipModel1;

/**
 * 
 * ��Ϣ��ʾ��
 * 
 * @author MOVELIGHTS
 * 
 */
public class TextTip1 extends Layer1 {

	private TextTipModel1 textTip = null;
	private Image bg = new ImageIcon("images/window/tip_01.png").getImage();
	
	private Point pointWindow = null;
	
	public TextTip1(int x, int y, int w, int h, TextTipModel1 textTip) {
		super(x, y, w, h);
		this.pointWindow = new Point((x + w) / 2, (y + h) / 2);
		this.textTip = textTip;

	}


	@Override
	public void paint(Graphics g) {
		// ������Ϣ���
		paintTextTip(g, this);
	}

	/**
	 * 
	 * ������Ϣ���
	 * 
	 */
	private void paintTextTip(Graphics g, TextTip1 textTip2) {
		if (textTip.getStartTick() < textTip.getNowTick()
				&& textTip.getNextTick() >= textTip.getNowTick()) {
			this.pointWindow.x = textTip.getPlayer().getX() + 45;
			this.pointWindow.y =textTip.getPlayer().getY() + 10;
			g.drawImage(bg, pointWindow.x, pointWindow.y, pointWindow.x + bg.getWidth(null),
					pointWindow.y + bg.getHeight(null), 0, 0, bg.getWidth(null),
					bg.getHeight(null), null);
			// ��������
			drawSting(g);
		}

	}

	/**
	 * 
	 * ��������
	 * 
	 */
	private void drawSting(Graphics g) {
		FontMetrics fm = g.getFontMetrics();
		String str = this.textTip.getTipString();
		int maxSize = 13;
		int posY = 32;
		int front = 0;
		int rear = maxSize;
		while (front < str.length() - 1) {
			if (rear >= str.length()) {
				rear = str.length() - 1;
			}
			char[] temp = new char[maxSize];
			str.getChars(front, rear, temp, 0);
			// Char[] ת����string
			String s = new String(temp);
			g.drawString(s, pointWindow.x + 20, pointWindow.y + posY);
			front = rear;
			rear += maxSize;
			posY += 20;
		}
	}

	@Override
	public void startPanel() {
	}
}
