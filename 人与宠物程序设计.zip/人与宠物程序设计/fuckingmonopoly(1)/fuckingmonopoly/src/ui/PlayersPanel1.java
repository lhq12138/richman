package ui;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.util.List;

import model.PlayerModel1;

/**
 * 
 * �����Ϣ���ˢ��
 * 
 * @author MOVELIGHTS
 * 
 */
public class PlayersPanel1 extends Layer1 {

	private List<PlayerModel1> players = null;

	protected PlayersPanel1(int x, int y, int w, int h, List<PlayerModel1> players) {
		super(x, y, w, h);
		this.players = players;
	}

	/**
	 * 
	 * �����Ϣ��ʾ������
	 * 
	 */
	public void paintPlayerInformation(Graphics g) {
		int tempX = 0;
		tempX += 30;
		for (PlayerModel1 temp : players) {
			// �����Ϣ������
			paintPlayerPanel(temp, g, tempX, 15);
			tempX += 80;
		}
	}

	/**
	 * 
	 * �����Ϣ������
	 * 
	 */
	private void paintPlayerPanel(PlayerModel1 player, Graphics g, int x,
			int y) {
		// �����Ϣ�ַ���
		String[] information = { player.getName(),
				Integer.toString(player.getCash()) + " ���",
				Integer.toString(player.getBuildings().size()) + " ����",
				 };
		// ͷ��(y += 60) + 20
		g.drawImage(player.getIMG("mini_02"), x -26 + 15 , y - 10, x -26 + 15 +player.getIMG("mini_02").getWidth(null) ,
				 y - 10 +player
					.getIMG("mini_02").getHeight(null) , 0, 0, player.getIMG("mini_02").getWidth(null), player
						.getIMG("mini_02").getHeight(null), null);
		y += 48;
		g.setColor(Color.DARK_GRAY);
		g.setFont(new Font(null,0,14));
		// ��Ϣ�ػ�
		FontMetrics fm = g.getFontMetrics();
		for (int k = 0; k < information.length; g.drawString(information[k], x
				+ (45 - fm.stringWidth(information[k])), y += 30), k++)
			;

	}

	@Override
	public void paint(Graphics g) {
		this.createWindow(g);
		// �����Ϣ��ʾ����ػ�
		this.paintPlayerInformation(g);
		
	}

	@Override
	public void startPanel() {
	}

}
