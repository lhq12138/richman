package ui;

import java.awt.Graphics;
import java.awt.Image;
import java.util.List;

import javax.swing.ImageIcon;

import control.GameRunning1;

import model.LandModel1;
import model.PlayerModel1;

/**
 * 
 * ���λ�����ݸ��²�
 * 
 * @author MOVELIGHTS
 * 
 */
public class Players1 extends Layer1 {

	private GameRunning1 run = null;
	private List<PlayerModel1> players = null;

	protected Players1(int x, int y, int w, int h) {
		super(x, y, w, h);
	}

	protected Players1(int x, int y, int w, int h,GameRunning1 run, List<PlayerModel1> players) {
		super(x, y, w, h);
		this.run = run;
		this.players = players;
	}

	public void paint(Graphics g) {
		// ��������ڵ�ͼ�����
		for (PlayerModel1 temp : players) {
			paintPlayer(temp, g);
		}
	}

	/**
	 * 
	 * ���Ƶ������
	 * 
	 */
	private void paintPlayer(PlayerModel1 player, Graphics g) {
		// �ж��Ƿ�Ϊ��ǰ���
		boolean show = true;
		Image temp = player.getIMG("mini");
		if (player.equals(this.run.getNowPlayer())) {
			temp = player.getIMG("mini_on");
		} else {
			if (this.x == player.getOtherPlayer().getX()
					&& this.y == player.getOtherPlayer().getY()) {
				// �غϲ���ʾ
				show = false;
			}
		}
		if (show)
			g.drawImage(temp, player.getX() + 28, player.getY() + 28, player.getX() + 60,
					player.getY() + 60, 0, 0, 32, 32, null);
	}


	@Override
	public void startPanel() {
	}
}
