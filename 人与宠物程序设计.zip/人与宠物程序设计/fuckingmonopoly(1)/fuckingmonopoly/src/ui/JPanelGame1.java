package ui;

import java.awt.BorderLayout;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JLayeredPane;
import javax.swing.JPanel;


import control.Control1;

@SuppressWarnings("serial")
public class JPanelGame1 extends JPanel{

	private JFrameGame1 gameFrame = null;
	private JLayeredPane layeredPane;

	private List<Layer1> lays = null;
	private Background1 backgroundUI = null;
	private Lands1 landsUI = null;
	private Buildings1 buildingsUI = null;
	private Players1 playersUI = null;
	private TextTip1 textTip = null;
	private PlayersPanel1 layerPlayersPanel = null;
	private Dice1 dice = null;
	private Event1 event = null;

	private Running1 running = null;
	private Effect1 effect = null;

	private PlayerInfo1 playerInfo = null;


	private Control1 control = null;

	/**
	 * ȫ�����Ͻ�X
	 */
	public int posX = 100;
	/**
	 * ȫ�����Ͻ�Y
	 * */
	public int posY = 100;

	public JPanelGame1() {
		setLayout(new BorderLayout());
		// ��ʼ����Ϸ
		initGame();
	}

	/**
	 * 
	 * ��ʼ����Ϸ
	 * 
	 */
	private void initGame() {
		// ���ӿ�����
		control = new Control1();
		// ��ʼ��UI
		initUI();
		// panel ���������
		control.setPanel(this);
	}

	public Control1 getControl() {
		return control;
	}

	/**
	 * 
	 * ��ʼ��UI
	 * 
	 */
	private void initUI() {
		// ��������UI
		this.backgroundUI = new Background1(0, 0, 950, 650,
				control.getBackground(),this);
		// ��������UI
		this.landsUI = new Lands1(posX, posY, 950, 650, control.getLand());
		// ��������UI
		this.buildingsUI = new Buildings1(posX, posY, 950, 650,
				control.getBuilding());
		// ���������ʾUI
		this.playersUI = new Players1(posX, posY, 950, 650,control.getRunning(), control.getPlayers());
		// �����Ϣ���UI
		this.layerPlayersPanel = new PlayersPanel1(posX + 64, posY + 66, 170,
				250, control.getPlayers());
		// ������ʾ���UI
		this.textTip = new TextTip1(0,0,950,650,control.getTextTip());
		// �����¼�UI
		this.dice = new Dice1(posX + 64, posY + 320, 170, 90, control);
		// �¼���ʾUI
		this.event = new Event1(0, 0, 950, 650, control.getEvents());
	
		// ��Ϸ��ת����UI
		this.running = new Running1(780, 0, 200, 80, control.getRunning(),this);
		// ����Ч��UI
		this.effect = new Effect1(0, 0, 950, 650, control.getEffect(),this);
		// �����Ϣ�����ʾ
		this.playerInfo = new PlayerInfo1(control.getPlayers(),this);


		// lays�������panel���
		lays = new ArrayList<Layer1>();
		lays.add(backgroundUI);
		lays.add(dice);
		lays.add(playersUI);
//		lays.add(textTip);
		lays.add(layerPlayersPanel);
		lays.add(buildingsUI);
		lays.add(landsUI);
		lays.add(backgroundUI);
		lays.add(running);
		lays.add(effect);
		// lays.add(shop);
		// lays.add(massageYesNo);

		layeredPane = new JLayeredPane();
		layeredPane.setLayout(null);

		int add = 1;
		//layeredPane.add(this.massageOk, add++);
		layeredPane.add(this.event, add++);
		layeredPane.add(this.effect, add++);
		layeredPane.add(this.textTip, add++);
		layeredPane.add(this.dice, add++);
		layeredPane.add(this.playersUI, add++);
		layeredPane.add(this.layerPlayersPanel, add++);
		layeredPane.add(this.buildingsUI, add++);
		layeredPane.add(this.landsUI, add++);
		layeredPane.add(this.running, add++);
		layeredPane.add(this.backgroundUI, add++);
		
		layeredPane.add(this.playerInfo,add++);

		
		//layeredPane.add(this.massageYesNo, add++);
		//layeredPane.add(this.massageSimple, add++);
		
		add(layeredPane);
	}

	
	public Running1 getRunning() {
		return running;
	}

	public Dice1 getDice() {
		return dice;
	}



	public JLayeredPane getLayeredPane() {
		return layeredPane;
	}

	public Background1 getBackgroundUI() {
		return backgroundUI;
	}

	public Effect1 getEffect() {
		return effect;
	}

	public JFrameGame1 getGameFrame() {
		return gameFrame;
	}

	public PlayerInfo1 getPlayerInfo() {
		return playerInfo;
	}

	public void setGameFrame(JFrameGame1 gameFrame) {
		this.gameFrame = gameFrame;
	}

	/**
	 * 
	 * ��ʼ����Ϸ����
	 * 
	 */
	public void startGamePanelInit() {
		for (Layer1 temp : this.lays) {
			// ˢ�´���UI
			temp.startPanel();
		}
	}

}
