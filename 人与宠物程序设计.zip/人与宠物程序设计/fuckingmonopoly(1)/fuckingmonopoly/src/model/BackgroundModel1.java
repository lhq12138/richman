package model;

import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;

import control.GameRunning1;

import ui.JPanelGame1;
import util.FileUtil1;

/**
 * 
 * ��������
 * 
 * @author MOVELIGHTS
 *
 */
public class BackgroundModel1 extends Tick1 implements Port1{
	/**
	 * ����ͼ��
	 */
	private Image bg = null;
	public BackgroundModel1 (){
	}
	
	public Image getBg() {
		return bg;
	}
	
	public void setBg(Image bg) {
		this.bg = bg;
	}

	/**
	 * 
	 * ��ʼ��Ϸ����
	 * 
	 */
	public void startGameInit (){
		this.bg = new ImageIcon("images/background/bg_0"+GameRunning1.MAP+".jpg").getImage();
	}
	@Override
	public void updata(long tick) {
		this.nowTick = tick;
	}
}
