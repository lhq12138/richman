package model;

import java.awt.Color;
import java.awt.Graphics;

import ui.JPanelGame1;
import ui.TextTip1;
import control.Control1;

/**
 * 
 * ������ʾ����
 * 
 * @author MOVELIGHTS
 * 
 */
public class TextTipModel1 extends Tick1 implements Port1{
	
	private PlayerModel1 player = null;
	
	private String tipString = "��Ϸ��ʼ��˭�������Ĵ����أ�";
	
	public TextTipModel1 (){
	}

	public  String getTipString() {
		return tipString;
	}

	public void setTipString(String tipString) {
		this.tipString = tipString;
	}
	
	
	/**
	 * 
	 * ��ʼ��Ϸ����
	 * 
	 */
	public void startGameInit (){}

	@Override
	public void updata(long tick) {
		this.nowTick = tick;
	}

	
	public PlayerModel1 getPlayer() {
		return player;
	}

	/**
	 * ��ʾ������ʾ
	 * 
	 * 
	 * */
	public void showTextTip(PlayerModel1 player,String str, int time) {
		this.player = player;
		this.setTipString(str);
		this.setStartTick(this.nowTick);
		this.setNextTick(this.nowTick + time * Control1.rate);
	}
}
