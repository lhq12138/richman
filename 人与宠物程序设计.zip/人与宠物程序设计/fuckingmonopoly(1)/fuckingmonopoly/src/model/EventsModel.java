package model;

import java.awt.Graphics;
import model.AutoplayerModel;
import java.awt.Image;

import javax.swing.ImageIcon;

import util.FileUtil;



import control.Control;

/**
 * 
 * �¼���Ϣ
 * 
 * @author MOVELIGHTS
 * 
 */
public class EventsModel extends Tick implements Port {

	/**
	 * ��ʾͼƬԴ
	 */
	private Image img = null;
	/**
	 * 
	 * ��͸����������ͼ ��ɫ
	 * 
	 */
	private Image BG_BRACK = new ImageIcon("images/event/bg_brack.png").getImage();
	/**
	 * ͼƬ��ʾλ��
	 */

	private boolean imgShow = false;

	
	public Image getBG_BRACK() {
		return BG_BRACK;
	}

	public Image getImg() {
		return img;
	}

	

	public boolean isImgShow() {
		return imgShow;
	}

	/**
	 * 
	 * ��ʾͼƬ
	 * 
	 */
	public void showImg(Image img, int time) {
		this.img = img;
		
		this.imgShow = true;
		this.setStartTick(this.nowTick);
		this.setNextTick(this.nowTick + time * Control.rate);
	}

	@Override
	public void updata(long tick) {
		this.nowTick = tick;
	}

	@Override
	public void startGameInit() {
	}
}
