package model.card;

import java.awt.Image;

import model.PlayerModel1;


public abstract class Card1 {

	/**
	 * 
	 * ��ƬӢ������
	 * 
	 */
	protected String name;
	/**
	 * 
	 * ��Ƭ��������
	 * 
	 */
	protected String cName;
	
	/**
	 * 
	 * ��ƬͼƬ
	 * 
	 */
	protected Image img;
	
	/**
	 * 
	 * ӵ����
	 * 
	 * 
	 */
	protected PlayerModel1 owner;
	
	/**
	 * 
	 * ���ö���
	 * 
	 */
	protected PlayerModel1 eOwner;
	
	/**
	 * 
	 * ��Ƭ�۸�
	 * 
	 */
	protected int price = 100;
	
	protected Card1 (PlayerModel1 owner) {
		this.owner =owner;
	}
	
	/**
	 * 
	 * ʹ�ÿ�ƬЧ��
	 * 
	 * 
	 */
	public abstract int useCard ();
	/**
	 * 
	 *  ��Ƭ����Ч��
	 * 
	 */
	public int cardBuff(){ return 0;}


	public String getName() {
		return name;
	}

	public Image getImg() {
		return img;
	}

	public PlayerModel1 getOwner() {
		return owner;
	}

	public void setOwner(PlayerModel1 owner) {
		this.owner = owner;
	}

	public int getPrice() {
		return price;
	}

	public String getcName() {
		return cName;
	}
	

	public PlayerModel1 geteOwner() {
		return eOwner;
	}

	public void seteOwner(PlayerModel1 eOwner) {
		this.eOwner = eOwner;
	}

	public void setcName(String cName) {
		this.cName = cName;
	}
	
	
}
