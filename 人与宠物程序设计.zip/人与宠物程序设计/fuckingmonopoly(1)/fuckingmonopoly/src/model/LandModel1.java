package model;

import java.awt.Image;
import java.awt.Point;

import javax.swing.ImageIcon;

import control.GameRunning1;

/**
 * ����
 * 
 * 
 * @author MOVELIGHTS
 * 
 */
public class LandModel1 extends Tick1 implements Port1 {
	/**
	 * 
	 * ����ͼƬ
	 * 
	 */
	private Image landsIMG = null;
	/**
	 * �յ�
	 */
	public final static int SPACE = 1;
	
	/**
	 * ҽԺ
	 */
	public final static int HOSPITAL = 8;

	/**
	 * ���
	 */
	public final static int ORIGIN = 10;
	/**
	 * ����
	 */
	public final static int PRISON = 11;
	/**
	 * �޽���
	 */
	public final static int NULL_SET = 0;
	/**
	 * ҽԺ��Ϣ
	 */
	public static Point hospital = new Point(0, 0);
	/**
	 * ������Ϣ
	 */
	public static Point prison = new Point(0, 0);

	public LandModel1() {
		this.landsIMG = new ImageIcon("images/window/land.jpg").getImage();
	}

	public Image getLandsIMG() {
		return landsIMG;
	}

	public void setLandsIMG(Image landsIMG) {
		this.landsIMG = landsIMG;
	}
	
	 protected int[][] land3 = {
			 // ģ�´�������һ����ͼ����
			 { ORIGIN, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, PRISON,SPACE, SPACE, SPACE, SPACE, SPACE },
				{ SPACE, NULL_SET, NULL_SET, NULL_SET, NULL_SET, NULL_SET, NULL_SET, NULL_SET,NULL_SET, NULL_SET, NULL_SET, NULL_SET, SPACE },
				{ HOSPITAL, NULL_SET, NULL_SET, NULL_SET, NULL_SET, NULL_SET, NULL_SET, NULL_SET,NULL_SET, NULL_SET, NULL_SET, NULL_SET, SPACE },
				{ SPACE, NULL_SET, NULL_SET, NULL_SET, NULL_SET, NULL_SET, NULL_SET, NULL_SET,NULL_SET, NULL_SET, NULL_SET, NULL_SET, SPACE },
				{ SPACE, NULL_SET, NULL_SET, NULL_SET, NULL_SET, NULL_SET, NULL_SET, NULL_SET,NULL_SET, NULL_SET, NULL_SET, NULL_SET, SPACE },
				{ SPACE, NULL_SET, NULL_SET, NULL_SET, NULL_SET, NULL_SET, NULL_SET, NULL_SET,NULL_SET, NULL_SET, NULL_SET, NULL_SET, SPACE },
				{ SPACE, NULL_SET, NULL_SET, NULL_SET, NULL_SET, NULL_SET, NULL_SET, NULL_SET,NULL_SET, NULL_SET, NULL_SET, NULL_SET, SPACE },
				{ SPACE, SPACE, PRISON, SPACE, SPACE, SPACE, SPACE, SPACE,HOSPITAL, SPACE, SPACE, SPACE, SPACE }};
	 
	

	 protected int[][] land;
	 
	public int[][] getLand() {
		return land;
	}

	/**
	 * ƥ���ͼ�¼�
	 * */
	public int matchLand(PlayerModel1 player) {
		return land[player.getY()][player.getX()];
	}

	/**
	 * 
	 * ��ʼ��Ϸ����
	 * 
	 */
	public void startGameInit() {
		if (GameRunning1.MAP == 1){
			land = land3;
		} 
	}

	@Override
	public void updata(long tick) {
		this.nowTick = tick;

	}
}
