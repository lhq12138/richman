package model;

import java.awt.Image;
import java.awt.Point;

import javax.swing.ImageIcon;

import control.Control1;

/**
 * 
 * �¼���Ϣ
 * 
 * @author MOVELIGHTS
 * 
 */
public class EffectModel1 extends Tick1 implements Port1 {

	Point loction = new Point(0,0);
	
	/**
	 * ��ʾͼƬԴ
	 */
	private Image[] img = null;
	/**
	 * 
	 * ����Ч����ʼ
	 * 
	 */
	private Image[] imgStart1 = {
			
			 new ImageIcon("images/effect/start1/14.png").getImage()
	};
	
	/**
	 * 
	 * WINЧ��
	 * 
	 */
	private Image[] win = {
		
			 new ImageIcon("images/effect/win/13.png").getImage()
	};
	/**
	 * 
	 * Բ��Ч����ʼ
	 * 
	 */
	private Image[] imgStart2 = {
			
			 new ImageIcon("images/effect/start2/10.png").getImage()
	};
	/**
	 * 
	 * ��Ϸ����Ч����ʼ
	 * 
	 */
	private Image[] timeover = {
			 
			 new ImageIcon("images/effect/timeover/16.png").getImage()
			 
	};
	
	/**
	 * 
	 * ��Ϸ����Ч����ʼ
	 * 
	 */
	private Image[] timeover2 = {
			
			 new ImageIcon("images/effect/timeover2/13.png").getImage()
	};
	/**
	 * 
	 * ��Ϸ����Ч����ʼ
	 * 
	 */
	private Image[] win_ = {
			
			 new ImageIcon("images/effect/win_/13.png").getImage()
	};
	/**
	 * 
	 * ��Ϸ����Ч����ʼ
	 * 
	 */
	private Image[] lose_ = {
			
			 new ImageIcon("images/effect/lose_/12.png").getImage()
	};
	
	/**
	 * ÿ��ͼƬ��ʾ��� ��/֡����
	 */
	private int imageShowGap = 3;
	
	/**
	 * 
	 * ��ʾͼƬ
	 * 
	 */
	public void showImg(String effectName) {
		if (effectName.equals("start")){
			this.img = imgStart2;
		} else if (effectName.equals("win")) {
			this.img = win;
		} else if (effectName.equals("timeover")) {
			this.img = timeover;
		} else if (effectName.equals("timeover2")) {
			this.img = timeover2;
		} else if (effectName.equals("win_")) {
			this.img = win_;
		} else if (effectName.equals("lose_")) {
			this.img = lose_;
		}
		this.setStartTick(this.nowTick);
		this.setNextTick(this.nowTick + (img.length + 1) *(Control1.rate / imageShowGap) - 1 );
	}

	public void showImg(String effectName,Point loction) {
		this.loction = loction;
		showImg(effectName);
	}
	public Image[] getImg() {
		return img;
	}

	public int getImageShowGap() {
		return imageShowGap;
	}

	@Override
	public void updata(long tick) {
		this.nowTick = tick;
	}

	@Override
	public void startGameInit() {
	}
}
