package model.buildings;

import model.PlayerModel1;
import context.GameState1;
import control.Control1;

/**
 * 
 * ��� ���ͨ��ʱ������Ǯ
 * 
 * 
 * @author MOVELIGHTS
 * 
 */
public class Origin1 extends Building1 {
	/**
	 * ͨ��ʱ�����Ľ�Ǯ
	 */
	private int passReward;
	/**
	 * ͣ��ʱ������Ǯ
	 */
	private int reward;

	private PlayerModel1 player;

	public Origin1(int posX, int posY) {
		super(posX, posY);
		this.name = "���";
		this.reward = 2000;
		this.passReward = 1000;
	}
	@Override
	public int getEvent() {
		return GameState1.ORIGIN_EVENT;
	}
	
	public int getPassReward() {
		return passReward;
	}
	public int getReward() {
		return reward;
	}
	@Override
	public int passEvent() {
		return GameState1.ORIGIN_PASS_EVENT;
	}
}
