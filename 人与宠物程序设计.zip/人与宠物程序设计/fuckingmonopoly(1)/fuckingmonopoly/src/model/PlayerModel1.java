package model;

import java.awt.Image;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

import model.buildings.Building1;
import model.card.Card1;
import control.Control1;
import control.GameRunning1;

/**
 * �����Ϣ
 * 
 * @author MOVELIGHTS
 * 
 */
public class PlayerModel1 extends Tick1 implements Port1 {

	/**
	 * ����
	 */
	private String name;
	/**
	 * ���ʹ������
	 */
	private int part = 0;
	/**
	 * �ֽ�
	 */
	private int cash;
	/**
	 * ���
	 */
	private int nx;

	/**
	 * ��ǰ���� x �������½ǵ�X
	 */
	private int x;
	/**
	 * ��ǰ���� y �������½ǵ�y
	 */
	private int y;

	/**
	 * 
	 * ʣ��סԺ����
	 * 
	 */
	private int inHospital;
	/**
	 * 
	 * ʣ���������
	 * 
	 */
	private int inPrison;

	/**
	 * 
	 * ��ұ��,��ʾ����ͼƬʹ��
	 * 
	 */
	private int number = 0;

	/**
	 * 
	 * ���ӵ�з�������
	 * 
	 */
	private List<Building1> buildings = new ArrayList<Building1>();

	/**
	 * 
	 * ӵ�п�Ƭ
	 * 
	 */


	/**
	 * 
	 * ���ɳ��п�Ƭ
	 * 
	 */


	/**
	 * 
	 * �������ϵ�EFFECT ��Ƭ
	 * 
	 */


	private Image[] playerIMG = new Image[100];

	/**
	 * 
	 * �Է����
	 * 
	 */
	private PlayerModel1 otherPlayer = null;
	/**
	 * 
	 * ��Ϸ������
	 * 
	 */
	private Control1 control = null;

	public PlayerModel1(int number, Control1 control) {
		this.name = "";
		this.number = number;
		this.control = control;
	}


	public List<Building1> getBuildings() {
		return buildings;
	}

	public int getInPrison() {
		return inPrison;
	}

	public void setInPrison(int inPrison) {
		this.inPrison = inPrison;
	}

	/**
	 * 
	 * ��ʼ�����ͼ��
	 * 
	 */
	private void initPlayerIMG() {
		// LOGO
		this.playerIMG[0] = new ImageIcon("images/player/" + this.getPart()
				+ "/logo.png").getImage();
		// mini_false
		this.playerIMG[1] = new ImageIcon("images/player/" + this.getPart()
				+ "/mini_01.png").getImage();
		// mini_true
		this.playerIMG[2] = new ImageIcon("images/player/" + this.getPart()
				+ "/mini_01_on.png").getImage();
		// head_h5
		this.playerIMG[3] = new ImageIcon("images/player/" + this.getPart()
				+ "/head_h5.png").getImage();
		// smile
		this.playerIMG[4] = new ImageIcon("images/player/" + this.getPart()
				+ "/smile.png").getImage();
		// sad
		this.playerIMG[5] = new ImageIcon("images/player/" + this.getPart()
				+ "/sad.png").getImage();
		// mini_02
		this.playerIMG[6] = new ImageIcon("images/player/" + this.getPart()
				+ "/mini_02.png").getImage();
	}

	/**
	 * 
	 * ��ȡ���ͼ��
	 * 
	 * @return <li>logo LOGO</li> <li>mini Сͼ��-�ޱ�</li> <li>mini_on Сͼ��-�б�</li>
	 *         <i>h5 ͼ�� </li> <li>other null</li>
	 */
	public Image getIMG(String str) {
		if (str.equals("logo"))
			return this.playerIMG[0];
		else if (str.equals("mini"))
			return this.playerIMG[1];
		else if (str.equals("mini_on"))
			return this.playerIMG[2];
		else if (str.equals("h5"))
			return this.playerIMG[3];
		else if (str.equals("smile"))
			return this.playerIMG[4];
		else if (str.equals("sad"))
			return this.playerIMG[5];
		else if (str.equals("mini_02"))
			return this.playerIMG[6];
		else
			return null;
	}

	public PlayerModel1 getOtherPlayer() {
		return otherPlayer;
	}

	public void setOtherPlayer(PlayerModel1 otherPlayer) {
		this.otherPlayer = otherPlayer;
	}

	public int getNumber() {
		return number;
	}

	public int getInHospital() {
		return inHospital;
	}

	public void setInHospital(int inHospital) {
		this.inHospital = inHospital;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPart() {
		return part;
	}

	public void setPart(int part) {
		this.part = part;
	}

	public int getCash() {
		return cash;
	}

	public void setCash(int cash) {
		this.cash = cash;
	}

	public int getNx() {
		return nx;
	}

	public void setNx(int nx) {
		this.nx = nx;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public void debug() {
		System.out.println("���:" + name + ",���꣺[" + x + "," + y + "].");
	}

	/**
	 * 
	 * ��ʼ��Ϸ����
	 * 
	 */
	public void startGameInit() {
		// ��ʼ�����ͼ��
		this.initPlayerIMG();
		// ���õ�λ����60px�����˶�ʱ��
		this.lastTime = Control1.rate / 5;
		// ��ʼ����ҽ�Ǯ
		this.cash = GameRunning1.PLAYER_CASH;
	}

	@Override
	public void updata(long tick) {
		this.nowTick = tick;
		// �ƶ����
		if (this.startTick < this.nowTick && this.nextTick >= this.nowTick) {
			this.control.movePlayer();
			// ·������
			if (this.nextTick != this.nowTick) {
				this.control.prassBuilding();
			}
			// ����ƶ���ϣ�ͣ�²���
			if (this.nextTick == this.nowTick) {
				this.control.playerStopJudge();
			}
		}
	}

}
