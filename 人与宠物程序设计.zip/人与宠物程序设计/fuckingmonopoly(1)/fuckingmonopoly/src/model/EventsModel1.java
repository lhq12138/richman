package model;

import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;

import util.FileUtil1;



import control.Control1;

/**
 * 
 * �¼���Ϣ
 * 
 * @author MOVELIGHTS
 * 
 */
public class EventsModel1 extends Tick1 implements Port1 {

	/**
	 * ��ʾͼƬԴ
	 */
	private Image img = null;
	/**
	 * 
	 * ��͸����������ͼ ��ɫ
	 * 
	 */
	private Image BG_BRACK = new ImageIcon("images/event/bg_brack.png").getImage();
	/**
	 * ͼƬ��ʾλ��
	 */

	private boolean imgShow = false;

	
	public Image getBG_BRACK() {
		return BG_BRACK;
	}

	public Image getImg() {
		return img;
	}

	

	public boolean isImgShow() {
		return imgShow;
	}

	/**
	 * 
	 * ��ʾͼƬ
	 * 
	 */
	public void showImg(Image img, int time) {
		this.img = img;
		
		this.imgShow = true;
		this.setStartTick(this.nowTick);
		this.setNextTick(this.nowTick + time * Control1.rate);
	}

	@Override
	public void updata(long tick) {
		this.nowTick = tick;
	}

	@Override
	public void startGameInit() {
	}
}
