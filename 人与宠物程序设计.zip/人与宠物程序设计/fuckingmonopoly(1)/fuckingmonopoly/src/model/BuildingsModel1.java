package model;

import java.util.ArrayList;
import java.util.List;

import model.buildings.Building1;
import model.buildings.Hospital1;
import model.buildings.House1;
import model.buildings.Origin1;
import model.buildings.Prison1;


/**
 * ȫ�ַ�����Ϣ
 * 
 * @author MOVELIGHTS
 * 
 */
public class BuildingsModel1 extends Tick1 implements Port1{
	/**
	 * ��������
	 */
	private List<Building1> buildings = null;
	
	private LandModel1 land = null;

	
	public BuildingsModel1 (LandModel1 land){
		this.land = land;
	}


	/**
	 * 
	 * ��ʼ������
	 * 
	 */
	private void initBuilding() {
		// ��ʼ������
		buildings = new ArrayList<Building1>();
		// ��Ӧ��ͼ���뷿��
		int[][] temp = this.land.getLand();
		for (int i = 0; i < temp.length; i++) {
			for (int j = 0; j < temp[i].length; j++) {
				switch (temp[i][j]) {
				case LandModel1.SPACE:
					Building1 tempBuidling = new House1(i, j);
					// ���ÿյص�����Ϊ���Թ����
					tempBuidling.setPurchasability(true);
					buildings.add(tempBuidling);
					break;
				case LandModel1.HOSPITAL:// ҽԺ
					buildings.add(new Hospital1(i, j));
					//����ȫͼҽԺ��
					LandModel1.hospital = new java.awt.Point(j * 60,i * 60);
//					System.out.println(LandModel.hospital );
					break;
				case LandModel1.ORIGIN:
					buildings.add(new Origin1(i, j));
					break;

				case LandModel1.PRISON:// ����
					buildings.add(new Prison1(i, j));
					//����ȫͼ������
					LandModel1.prison = new java.awt.Point(j * 60, i * 60);
//					System.out.println(LandModel.prison );
					break;
				default:
					break;
				}
			}
		}
	}

	/**
	 * 
	 * ��÷��ݱ�
	 * 
	 * @return
	 */
	public List<Building1> getBuilding(){
		return buildings;
	}
	/**
	 * 
	 * ��õ�ǰλ�÷���
	 * 
	 */
	public Building1 getBuilding(int x,int y){
		for (Building1 temp : this.buildings){
			if (temp.getPosX() == x && temp.getPosY() == y){
				return temp;
			}
		}
		return null;
	}
	/**
	 * 
	 * ��ʼ��Ϸ����
	 * 
	 */
	public void startGameInit (){
		// ��ʼ������
		initBuilding();
	}

	@Override
	public void updata(long tick) {
		this.nowTick = tick;
		
	}
}