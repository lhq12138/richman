package Main;

import java.io.Serializable;
import model.AutoplayerModel;

public class user implements Serializable{

	public user(String uid, String upw, String uname) {
		super();
		this.uid = uid;
		this.upw = upw;
		this.uname = uname;
	}
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getUpw() {
		return upw;
	}
	public void setUpw(String upw) {
		this.upw = upw;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	String uid;
	String upw;
	String uname;


}
