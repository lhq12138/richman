package Main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import model.AutoplayerModel;

public class DataConnect {
	private static Statement stat;
	private static void init() throws SQLException, ClassNotFoundException{
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("�������ݿ�");
		Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/test","root","123456");
		stat = conn.createStatement();
		
		
	}

	public static Statement getStatment() throws ClassNotFoundException, SQLException{
		if(stat==null)
			init();
		return stat;
	}


}
