package Main;

import java.io.Serializable;

public class user1 implements Serializable{

	public user1(String uid, String upw, String uname) {
		super();
		this.uid = uid;
		this.upw = upw;
		this.uname = uname;
	}
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getUpw() {
		return upw;
	}
	public void setUpw(String upw) {
		this.upw = upw;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	String uid;
	String upw;
	String uname;


}
