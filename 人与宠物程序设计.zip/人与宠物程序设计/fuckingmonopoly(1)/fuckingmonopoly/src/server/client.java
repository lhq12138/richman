package server;

import java.io.*;
import model.AutoplayerModel;
import java.net.*;

import Main.user;

public class client {
	ObjectOutputStream oos;
	ObjectInputStream ois;
	
	
	final int LOGIN = 1001;
	final int REGISTER = 1002;
	public client() throws UnknownHostException, IOException{
		Socket s = new Socket("192.168.43.225",23456);
		oos= new ObjectOutputStream(s.getOutputStream());
		ois= new ObjectInputStream(s.getInputStream());

	}
	public user login(String uid,String upw) throws IOException, ClassNotFoundException{
		oos.writeInt(LOGIN);
		oos.flush();
		oos.writeUTF(uid);
		oos.flush();
		oos.writeUTF(upw);
		oos.flush();
		return (user) ois.readObject();
		
		
	}
	public user regiter(String uid,String upw,String uname) throws IOException, ClassNotFoundException{
		oos.writeInt(REGISTER);
		oos.flush();
		oos.writeUTF(uid);
		oos.flush();
		oos.writeUTF(upw);
		oos.flush();
		oos.writeUTF(uname);
		oos.flush();
		return (user) ois.readObject();
		
		
	}

}
