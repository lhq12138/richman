package server;

import java.io.*;
import model.AutoplayerModel;
import java.net.*;
import java.sql.*;

import Main.DataConnect;
import Main.user;

public class Server {
	ObjectInputStream ois;
	ObjectOutputStream oos;
	Socket s;
	final int LOGIN = 1001;
	final int REGISTER = 1002;

	
	public Server() throws IOException, ClassNotFoundException, SQLException{
		ServerSocket ss = new ServerSocket(23456);
		while(true){
			s=ss.accept();
			ois= new ObjectInputStream(s.getInputStream());
			oos= new ObjectOutputStream(s.getOutputStream());
			
			int command = ois.readInt();
			if(command == LOGIN){
				login();
			}
			if(command==REGISTER){
				regiter();
			}
		}
	}




	public void login() throws IOException, ClassNotFoundException, SQLException{
		String uid = ois.readUTF();
		String upw = ois.readUTF();
		user u = null;
		String sql = "select * from user where uid='"+uid+"'and upw='"+upw+"'";
		ResultSet rs = DataConnect.getStatment().executeQuery(sql);
		if(rs.next())
			u = new user(rs.getString(1),rs.getString(2),rs.getString(3));
		oos.writeObject(u);
		oos.flush();
		
	}
	public void regiter() throws IOException {
		String uid = ois.readUTF();
		String upw = ois.readUTF();
		String uname = ois.readUTF();
		user u = null;
		String sql = "insert into user values('"+uid+"','"+upw+"','"+uname+"')";
		 try {
			DataConnect.getStatment().executeUpdate(sql);
			oos.writeObject(new user(uid,upw,uname));
			oos.flush();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			oos.writeObject(null);
			oos.flush();
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
	public static void main(String[] args){
		try {
			new Server();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
