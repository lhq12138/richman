package util;

import control.GameRunning1;

public class MyThread1 implements Runnable{
	
	private GameRunning1 run;
	
	int times;
	
	int time;
	
	public MyThread1 (GameRunning1 run,int times) {
		this.run = run;
		this.times = times;
	}
	@Override
	public void run() {
		while (true) {
			if (time >= times){
				run.nextState();
				break;
			}
			time++;
			try {
				Thread.sleep(1000);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	public void start() {
		this.run();
	}

}
