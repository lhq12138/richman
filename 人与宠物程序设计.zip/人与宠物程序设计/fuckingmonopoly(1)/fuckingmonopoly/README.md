# MiniMONOPOLY
A Java Swing (GUI) game.   
单机版的大富翁游戏，纯Java实现，采用MVC设计模式。  

所有素材来自 大富翁客户端+冒险岛客户端。

## ScreenShot
![](https://github.com/moonChenHaohui/blog/blob/gh-pages/image/minimonopoly/game.gif)
![](https://github.com/moonChenHaohui/blog/blob/gh-pages/image/minimonopoly/game1.gif)

## Other

这个项目适合掌握基本Java知识，对游戏、绘图机制比较感兴趣，并且想运用设计模式的同学。




 



